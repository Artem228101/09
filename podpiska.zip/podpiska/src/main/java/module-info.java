module com.example.podpiska {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.podpiska to javafx.fxml;
    exports com.example.podpiska;
    exports com.example.podpiska.Controller;
    opens com.example.podpiska.Controller to javafx.fxml;
    exports com.example.podpiska.database;
    opens com.example.podpiska.database to javafx.fxml;
    opens sample to javafx.fxml;
}