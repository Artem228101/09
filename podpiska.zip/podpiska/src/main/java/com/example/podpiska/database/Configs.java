package com.example.podpiska.database;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "root";
    protected String dbName = "movie subscription";
}